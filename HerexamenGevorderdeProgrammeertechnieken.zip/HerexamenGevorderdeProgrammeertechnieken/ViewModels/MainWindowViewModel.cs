﻿using HerexamenGevorderdeProgrammeertechnieken.Navigatie;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerexamenGevorderdeProgrammeertechnieken.ViewModels
{
    public class MainWindowViewModel : BasisViewModel
    {
        public INavigator Navigate => UpdateViewModel.Navigate;

        public MainWindowViewModel()
        {
            Navigate.SetViewModel.Execute("UserControlHome");
        }
         
        public override string this[string columnName] => throw new NotImplementedException();

        public override bool CanExecute(object parameter)
        {
            throw new NotImplementedException();
        }

        public override void Execute(object parameter)
        {
            throw new NotImplementedException();
        }
    }
}
